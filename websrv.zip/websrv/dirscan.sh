#!/bin/bash

# Directories to search
directories=(
    "/tmp"
    "/var/tmp"
    "/var/www"
    "/opt"
    "/usr/local/bin"
    "/usr/local/sbin"
    "/usr/bin"
    "/usr/sbin"
    "/mnt"
)

# Add all users' home directories
for home in /home/*; do
    if [ -d "$home" ]; then
        directories+=("$home")
    fi
done

# Function to perform ls -lahR on a directory
perform_ls() {
    dir=$1
    echo "Listing contents of $dir:"
    ls -lahR "$dir"
    echo
}

# Function to list directories recursively
list_directories_recursively() {
    echo "directories in $1:"
    find "$1" -type d
    echo
}

# Redirect all output to dirscan.txt
output_file="dirscan.txt"
exec > "$output_file" 2>&1

# Iterate over directories and perform ls -lahR
for dir in "${directories[@]}"; do
    perform_ls "$dir"
done

# Append directory listing (folders only, recursively) to dirscan.txt
echo "--------------------------------------------------" >> "$output_file"
echo "Listing directories:" >> "$output_file"
echo >> "$output_file"

for dir in "${directories[@]}"; do
    list_directories_recursively "$dir" >> "$output_file"
done
